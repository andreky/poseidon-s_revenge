/*! \file monstro.c
 * \brief Arquivo que contem funções de inicialização dos monstros e funções de colisão com monstros */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "monstro.h"

/*! \brief Inicializa um monstro
 * \param indicaMonstro Número que indica qual monstro é inicializado
 * \param Xini Coordenada x inicial
 * \param Yini Coordenada y inicial 
 * \param largura Largura da imagem do monstro
 * \param altura Altura da imagem do monstro
 * \param vida Quantidade de vida do monstro
 * \param angulo Angulo da imagem do monstro
 * \param sentidoMovimento Sentido de movimento do novo monstro */
monstro initMonstro(int indicaMonstro, int Xini, int Yini, int largura, int altura, int vida, float angulo, int sentidoMovimento)
{
  monstro inimigo = malloc(sizeof *inimigo);
  inimigo->objMonstro = initDot(Xini, Yini, largura, altura, vida, FALSE, angulo);
  inimigo->indicaMonstro = indicaMonstro;
  inimigo->initX = Xini;
  inimigo->initY = Yini;
  inimigo->sentidoMov = sentidoMovimento;
  inimigo->next = NULL;
  
  return inimigo;
}

/*! \brief Libera um monstro
 * \param libera O monstro que deve ser liberado */
void liberaMonstro(monstro libera)
{
  if(libera){
    free(libera);
    libera = NULL;
  }
}

/*! \brief Verifica se aumentou a distância ente o barco e algum monstro da fase atual
 * \param barco Círculo do barco do jogador
 * \param cabeca Cabeca da lista ligada de monstros da fase atual
 * \param deltaX Possível incremento/decremento para o x do barco
 * \param deltaY Possível incremento/decremento para o y do barco
 * \return 1 caso a distância tenha aumentado, 0 caso contrário */
int aumentouDistanciaMonstro(circ barco, monstro cabeca, int deltaX, int deltaY)
{
  int distanciou = TRUE;
  monstro apontaMonstro;
  for(apontaMonstro = cabeca->next; apontaMonstro; apontaMonstro = apontaMonstro->next)
    if(checaColisao(barco, apontaMonstro->objMonstro->circulo) == TRUE)
      if(apontaMonstro->indicaMonstro != TORNADO){/*ele pode passar por cima do tornado*/
	if(aumentouDistancia(barco, apontaMonstro->objMonstro->circulo, deltaX, deltaY) == FALSE){
	  distanciou = FALSE;
	  break;
	}
      }
  if(distanciou == TRUE)
    for(apontaMonstro = cabeca->next; apontaMonstro; apontaMonstro = apontaMonstro->next)
      apontaMonstro->objMonstro->parado = FALSE;
  return distanciou;
}

/*! \brief Verifica se ocorreu colisão do barco com algum monstro da fase atual
 * \param barco Barco do jogador
 * \param cabeca Cabeca da lista de ligada de monstros 
 * \return 1 caso tenha ocorrido alguma colisão, 0 caso contrário */
int colisaoBarco(Dot barco, monstro cabeca)
{
  int  colidiu = FALSE;
  monstro apontaInimigo;
  for(apontaInimigo = cabeca->next; apontaInimigo; apontaInimigo = apontaInimigo->next){
    if(checaColisao(barco->circulo, apontaInimigo->objMonstro->circulo) == TRUE){
      if(apontaInimigo->indicaMonstro != TORNADO){/*coloquei esse if para o tornado*/
	apontaInimigo->objMonstro->parado = TRUE;
	colidiu = TRUE;
	barco->vida -= 1;
	if(barco->vida <= 0)
	  barco->fase = GAME_OVER;
      }
    }
    else
      apontaInimigo->objMonstro->parado = FALSE;
  }
  return colidiu;
}

/*! \brief Verifica se ocorreu colisão entre um ataque com algum monstro e ja causa danos no monstro
 * \param ataque Objeto que representa um ataque do jogador
 * \param cabeca Cabeça da lista ligada de monstros
 * \param dano Valor do dano causado ao monstro pelo ataque
 * \param barco Barco do jogador
 * \return 1 caso tenha ocorrido colisão entre um ataque e algum monstro, 0 caso contrário */
int colisaoAtaqueUnico(Dot ataque, monstro cabeca, int dano, Dot barco)
{
  monstro apontaInimigo, remove;
  for(apontaInimigo = cabeca; apontaInimigo->next; apontaInimigo = apontaInimigo->next)
    if(checaColisao(ataque->circulo, apontaInimigo->next->objMonstro->circulo) == TRUE){
      apontaInimigo->next->objMonstro->vida -= dano; /************/
      if(apontaInimigo->next->objMonstro->vida <= 0){
        if(apontaInimigo->next->indicaMonstro == KRAKEN)
          barco->pontos += 1000;
        else if(apontaInimigo->next->indicaMonstro == SERPENTE)
          barco->pontos += 300;
        else if(apontaInimigo->next->indicaMonstro == HARPIA)
          barco->pontos += 100;
        else if(apontaInimigo->next->indicaMonstro == BARCOINIMIGO)
          barco->pontos += 250;
        else if(apontaInimigo->next->indicaMonstro == CATAPULTA)
          barco->pontos += 500;
        remove = apontaInimigo->next;
	apontaInimigo->next = remove->next;
        liberaMonstro(remove);
      }
      return TRUE;
    }
  return FALSE;
}

/*! \brief Executa o ataque em área da águia
 * \param ataque Objeto representando o ataque lançado
 * \param cabeca Cabeça da lista liagda de monstros
 * \param dano Dano causado ao monstro pelo ataque
 * \param barco Barco do jogador */
void colisaoAtaqueArea(Dot ataque, monstro cabeca, int dano, Dot barco)
{
  int ataqueIndiceVetor, ataqueX, ataqueY, deltaX, deltaY, monstroX, monstroY; 
  monstro apontaInimigo, remove;
  ataqueIndiceVetor = ataque->indiceVetor;
  ataqueX = ataque->circulo->circuloX;
  ataqueY = ataque->circulo->circuloY;
  deltaX = ataque->distanciaPercorrida * cos(ataque->angulo);
  deltaY = ataque->distanciaPercorrida * sin(ataque->angulo) * -1;
  for(apontaInimigo = cabeca; apontaInimigo->next;){
    monstroX = apontaInimigo->next->objMonstro->circulo->circuloX;
    monstroY = apontaInimigo->next->objMonstro->circulo->circuloY;
    if(!(ataqueIndiceVetor > 4 && ataqueIndiceVetor <= 12) && ataqueX - deltaX <= monstroX && ataqueX >= monstroX &&
       checaColisao(ataque->circulo, apontaInimigo->next->objMonstro->circulo) == TRUE){
      apontaInimigo->next->objMonstro->vida -= dano;
      /*printf("%d\n", apontaInimigo->next->objMonstro->vida);*/
      if(apontaInimigo->next->objMonstro->vida <= 0){
        if(apontaInimigo->next->indicaMonstro == KRAKEN)
          barco->pontos += 1000;
        else if(apontaInimigo->next->indicaMonstro == SERPENTE)
          barco->pontos += 500;
        else if(apontaInimigo->next->indicaMonstro == HARPIA)
          barco->pontos += 100;
        else if(apontaInimigo->next->indicaMonstro == BARCOINIMIGO)
          barco->pontos += 250;
        remove = apontaInimigo->next;
	apontaInimigo->next = remove->next;
        liberaMonstro(remove);
      }
      else
        apontaInimigo = apontaInimigo->next;
    }
    else if(ataqueIndiceVetor > 4 && ataqueIndiceVetor <= 12 && ataqueX - deltaX >= monstroX && ataqueX <= monstroX &&
	    checaColisao(ataque->circulo, apontaInimigo->next->objMonstro->circulo) == TRUE){
      apontaInimigo->next->objMonstro->vida -= dano;
      /*printf("%d\n", apontaInimigo->next->objMonstro->vida);*/
      if(apontaInimigo->next->objMonstro->vida <= 0){
        if(apontaInimigo->next->indicaMonstro == KRAKEN)
          barco->pontos += 1000;
        else if(apontaInimigo->next->indicaMonstro == SERPENTE)
          barco->pontos += 500;
        else if(apontaInimigo->next->indicaMonstro == HARPIA)
          barco->pontos += 100;
        else if(apontaInimigo->next->indicaMonstro == BARCOINIMIGO)
          barco->pontos += 250;
        remove = apontaInimigo->next;
	apontaInimigo->next = remove->next;
        liberaMonstro(remove);
      }
      else
        apontaInimigo = apontaInimigo->next;
    }
    else if(!(ataqueIndiceVetor > 4 && ataqueIndiceVetor <= 12) && ataqueY - deltaY <= monstroY && ataqueY >= monstroY &&
            checaColisao(ataque->circulo, apontaInimigo->next->objMonstro->circulo) == TRUE){
      apontaInimigo->next->objMonstro->vida -= dano;
      /*printf("%d\n", apontaInimigo->next->objMonstro->vida);*/
      if(apontaInimigo->next->objMonstro->vida <= 0){
        if(apontaInimigo->next->indicaMonstro == KRAKEN)
          barco->pontos += 1000;
        else if(apontaInimigo->next->indicaMonstro == SERPENTE)
          barco->pontos += 500;
        else if(apontaInimigo->next->indicaMonstro == HARPIA)
          barco->pontos += 100;
        else if(apontaInimigo->next->indicaMonstro == BARCOINIMIGO)
          barco->pontos += 250;
        remove = apontaInimigo->next;
	apontaInimigo->next = remove->next;
        liberaMonstro(remove);
      }
      else
        apontaInimigo = apontaInimigo->next;
    }
    else if(ataqueIndiceVetor > 4 && ataqueIndiceVetor <= 12  &&ataqueY - deltaY >= monstroY && ataqueY <= monstroY &&
            checaColisao(ataque->circulo, apontaInimigo->next->objMonstro->circulo) == TRUE){
      apontaInimigo->next->objMonstro->vida -= dano;
      /*printf("%d\n", apontaInimigo->next->objMonstro->vida);*/
      if(apontaInimigo->next->objMonstro->vida <= 0){
        if(apontaInimigo->next->indicaMonstro == KRAKEN)
          barco->pontos += 1000;
        else if(apontaInimigo->next->indicaMonstro == SERPENTE)
          barco->pontos += 500;
        else if(apontaInimigo->next->indicaMonstro == HARPIA)
          barco->pontos += 100;
        else if(apontaInimigo->next->indicaMonstro == BARCOINIMIGO)
          barco->pontos += 250;
        remove = apontaInimigo->next;
	apontaInimigo->next = remove->next;
        liberaMonstro(remove);
      }
      else
        apontaInimigo = apontaInimigo->next;
    }
    else
      apontaInimigo = apontaInimigo->next;
  }
}
