/*! \file kraken.c
 * \brief Arquivo que contem a função de carregamento de imagens do kraken e sua movimentação */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "image.h"
#include "monstro.h"

/*! \brief Objeto que representa o ataque lançado pelo kraken */
Dot ataqueKraken = NULL;
/*! \brief A maior distância que o ataque do kraken pode percorrer */
int distanciaMaxima;

/*O karken soh tem uma imagem, mas desse jeito seguimos a mesma logica das flechas, do barco, etc.*/
/*! \brief Função responsável pelo carregamento da imagem do kraken
 * \param vetorKraken Vetor do tipo SDL_Surface onde será armazenada a imagem do kraken 
 * \param vetorAtaqueKraken Vetor do tipo SDL_Surface onde será armazenada a imagem do ataque do kraken */
void carregaVetorImagensKraken(SDL_Surface **vetorKraken, SDL_Surface **vetorAtaqueKraken)
{
  vetorKraken[0] = load_image("imagens/monstros/kraken.png");
  vetorAtaqueKraken[0] = load_image("imagens/ataques/ataqueKraken.png");
}

/*! \brief Função responsável por liberar o ataque do kraken */
void liberaAtaqueKraken()
{
  liberaDot(ataqueKraken);
  ataqueKraken = NULL;
}

/*! \brief Move o ataque lançado pelo Kraken
 * \param barco Barco do jogador
 * \param kraken Objeto representando o kraken */
void moveAtaque(Dot barco, monstro kraken)
{
  if(ataqueKraken == NULL){
    ataqueKraken = initDot(kraken->objMonstro->x, kraken->objMonstro->y + (kraken->objMonstro->altura / 2), 50, 50, 0, FALSE, 0.0);
    ataqueKraken->distanciaPercorrida = -12;
    distanciaMaxima = 400;
  }
  else{
    ataqueKraken->x += ataqueKraken->distanciaPercorrida;
    ataqueKraken->circulo->circuloX += ataqueKraken->distanciaPercorrida;
    distanciaMaxima += ataqueKraken->distanciaPercorrida;
    if(checaColisao(barco->circulo, ataqueKraken->circulo)){
      barco->vida -= 50;
      liberaAtaqueKraken();
      if(barco->vida <= 0)
      	barco->fase = GAME_OVER;
    }
    else if(distanciaMaxima <= 0){
      liberaAtaqueKraken();
    }
  }
}

/*! \brief Move o kraken
 * \param kraken Objeto que representa o kraken
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEE_HEIGHT Altura da tela de jogo */
void moveKraken(monstro kraken, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{
  int distanciaY = 5;
  int mudaSentido = rand()%20;
  kraken->objMonstro->y += distanciaY*(kraken->sentidoMov);
  if(kraken->objMonstro->y > SCREEN_HEIGHT - kraken->objMonstro->altura - 6){/*6 por causa da barra de vida do kraken*/
    if(mudaSentido == 0)
      kraken->sentidoMov *= -1;
    kraken->objMonstro->y = SCREEN_HEIGHT - kraken->objMonstro->altura - 6;
  }
  if(kraken->objMonstro->y < 0){
    if(mudaSentido == 0)
      kraken->sentidoMov *= -1;
    kraken->objMonstro->y = 0;
  }
  kraken->objMonstro->circulo->circuloY = kraken->objMonstro->y + (kraken->objMonstro->altura / 2);
}

/*! \brief Aplica na tela o ataque lançado pelo kraken
 * \param vetorAtaqueKraken Vetor onde estão armazenadas as imagens do ataque do kraken 
 * \param screen Tela de jogo */
void imprimeAtaqueKraken(SDL_Surface **vetorAtaqueKraken, SDL_Surface *screen)
{
  if(ataqueKraken != NULL)
    apply_surface(ataqueKraken->x, ataqueKraken->y, vetorAtaqueKraken[0], screen, NULL);
}
