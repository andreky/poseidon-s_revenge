/*! \file bolas.h
 * \brief Interface de bolas.c */
#include "image.h"
#include "dot.h"

void initBolas();

void liberaBolas();

void bolasPosicao(int x,int y,int fase,Dot obstaculo1,Dot obstaculo2,Dot obstaculo3, Dot porto);

void imprimeBolas(SDL_Surface *screen,Dot barco);
