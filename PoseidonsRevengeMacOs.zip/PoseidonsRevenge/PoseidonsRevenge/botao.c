/*! \file botao.c
 * \brief Arquivo com as funções referentes aos botões do jogo */
#include <string.h>
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "botao.h"
#include "image.h"
#define TRUE 1
#define FALSE 0

/*! \brief Cria um novo botão
 * \param x Coordenada x do novo botão
 * \param y Coordenada y do novo botão
 * \param w Largura do novo botão
 * \param h Altura do novo botão
 * \param indice O primeiro índice no vetor de imagens correpondente a esse botão
 * \return Retorna o novo botão */
bot Botao(int x, int y, int w, int h, int indice)
{
  bot novo;
  novo = malloc(sizeof *novo);
  novo->caixa.x = x;
  novo->caixa.y = y;
  novo->caixa.w = w;
  novo->caixa.h = h;
  novo->indiceBotaoAtual = indice;
  novo->indiceBotaoAnterior = indice;
  return novo;
}

/*! \brief Libera um botão
 * \param libera O botão que deve ser liberado */
void liberaBotao(bot libera)
{
  if(libera){
    free(libera);
    libera = NULL;
  }
}

/*! \brief Carrega as imagens do botão jogar
 * \param vetorBotaoJogar Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão jogar */
void carregaBotaoJogar(SDL_Surface **vetorBotaoJogar)
{
  vetorBotaoJogar[0] = load_image("imagens/botoes/botaoJogar1.png");
  vetorBotaoJogar[1] = load_image("imagens/botoes/botaoJogar2.png");
}

/*! \brief Carrega as imagens do botão próximo
 * \param vetorBotaoProximo Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão próximo */
void carregaBotaoProximo(SDL_Surface **vetorBotaoProximo)
{
  vetorBotaoProximo[0] = load_image("imagens/botoes/botaoProximo1.png");
  vetorBotaoProximo[1] = load_image("imagens/botoes/botaoProximo2.png");
}

/*! \brief Carrega as imagens dos botões de upgrades
 * \param vetorBotoesUps Vetor do tipo SDL_Surface onde serão armazenadas as imagens dos botões de upgrades */
void carregaBotoesUps(SDL_Surface **vetorBotoesUps)
{
  vetorBotoesUps[0] = load_image("imagens/botoes/botaoAguia1.png");
  vetorBotoesUps[1] = load_image("imagens/botoes/botaoAguia2.png");
  vetorBotoesUps[2] = load_image("imagens/botoes/botaoBolsaVentos1.png");
  vetorBotoesUps[3] = load_image("imagens/botoes/botaoBolsaVentos2.png");
  vetorBotoesUps[4] = load_image("imagens/botoes/botaoFlechaFogo1.png");
  vetorBotoesUps[5] = load_image("imagens/botoes/botaoFlechaFogo2.png");
  vetorBotoesUps[6] = load_image("imagens/botoes/botaoVida1.png");
  vetorBotoesUps[7] = load_image("imagens/botoes/botaoVida2.png");
  vetorBotoesUps[8] = load_image("imagens/botoes/botaoMagia1.png");
  vetorBotoesUps[9] = load_image("imagens/botoes/botaoMagia2.png");
  vetorBotoesUps[10] = load_image("imagens/botoes/botaoEnergia1.png");
  vetorBotoesUps[11] = load_image("imagens/botoes/botaoEnergia2.png");
}

/*! \brief Carrega as imagens do botão pular
 * \param vetorBotaoPular Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão pular */
void carregaBotaoPular(SDL_Surface **vetorBotaoPular)
{
  vetorBotaoPular[0] = load_image("imagens/botoes/botaoPular1.png");
  vetorBotaoPular[1] = load_image("imagens/botoes/botaoPular2.png");
}

/*! \brief Carrega as imagens do botão de créditos
 * \param vetorBotaoCreditos Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão de créditos */
void carregaBotaoCreditos(SDL_Surface **vetorBotaoCreditos)
{
  vetorBotaoCreditos[0] = load_image("imagens/botoes/botaoCreditos1.png");
  vetorBotaoCreditos[1] = load_image("imagens/botoes/botaoCreditos2.png");
}

/*! \brief Carrega as imagens do botão de instruções
 * \param vetorBotaoInstrucoes Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão de instruções */
void carregaBotaoInstrucoes(SDL_Surface **vetorBotaoInstrucoes)
{
  vetorBotaoInstrucoes[0] = load_image("imagens/botoes/botaoInstrucao1.png");
  vetorBotaoInstrucoes[1] = load_image("imagens/botoes/botaoInstrucao2.png");
}

/*! \brief Carrega as imagens do botão começar
 * \param vetorBotaoComeçar Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão começar */
void carregaBotaoComecar(SDL_Surface **vetorBotaoComecar)
{
  vetorBotaoComecar[0] = load_image("imagens/botoes/botaoComecar1.png");
  vetorBotaoComecar[1] = load_image("imagens/botoes/botaoComecar2.png");
}

/*! \brief Carrega as imagens do botão de tela inicial
 * \param vetorBotaoInicial Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão de tela inicial */
void carregaBotaoInicial(SDL_Surface **vetorBotaoInicial)
{
  vetorBotaoInicial[0] = load_image("imagens/botoes/botaoTelaInicial1.png");
  vetorBotaoInicial[1] = load_image("imagens/botoes/botaoTelaInicial2.png");
}

/*! \brief Carrega as imagens do botão de som
 * \param vetorBotaoSom Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão de som */
void carregaBotaoSom(SDL_Surface **vetorBotaoSom)
{
  vetorBotaoSom[0] = load_image("imagens/botoes/botaoSom1.png");
  vetorBotaoSom[1] = load_image("imagens/botoes/botaoSom2.png");
}

/*! \brief Carrega as imagens do botão anterior
 * \param vetorBotaoAnterior Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão anterior */
void carregaBotaoAnterior(SDL_Surface **vetorBotaoAnterior)
{
  vetorBotaoAnterior[0] = load_image("imagens/botoes/botaoAnterior1.png");
  vetorBotaoAnterior[1] = load_image("imagens/botoes/botaoAnterior2.png");
}

/*! \brief Lida com os eventos referentes a um botão, como o pressionamento de um botão 
 * \param botao Objeto representando o botão analisado
 * \param evento Um evento do tipo SDL_Event
 * \return 1 caso o botão seja apertado, 0 caso contrário */
int handle_events(bot botao, SDL_Event evento)
{
  int x, y;
  if(evento.type == SDL_MOUSEBUTTONDOWN){
    if(evento.button.button == SDL_BUTTON_LEFT){
      x = evento.button.x;
      y = evento.button.y;
      if((x > botao->caixa.x) && (x < botao->caixa.x + botao->caixa.w) && (y > botao->caixa.y) && (y < botao->caixa.y + botao->caixa.h)){
       	botao->indiceBotaoAnterior = botao->indiceBotaoAtual;
        botao->indiceBotaoAtual = botao->indiceBotaoAnterior + 1;
      }
    }
  }
  if(evento.type == SDL_MOUSEBUTTONUP){
    if(evento.button.button == SDL_BUTTON_LEFT && botao->indiceBotaoAtual == botao->indiceBotaoAnterior + 1){
      botao->indiceBotaoAtual = botao->indiceBotaoAnterior;
      return TRUE;
    }
  }
  return FALSE;
}
