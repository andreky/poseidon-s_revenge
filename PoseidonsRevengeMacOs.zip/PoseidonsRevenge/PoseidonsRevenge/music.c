/*! \file music.c
 * \brief Arquivo que contem as funções referentes à música. Elas foram retiradas do tutorial de SDL do lazyfoo. */
#include <stdio.h>
#include "SDL_mixer.h"
#include "music.h"

/*! \brief Carrega as músicas no vetor music
 * \param music Vetor do tipo Mix_Music no qual são armazenadas as músicas do jogo 
 * \return 1 caso tenha ocorrido algum erro, 0 caso contrário */
int carregaVetorMusica(Mix_Music **music)
{
  if( Mix_OpenAudio( 22050, MIX_DEFAULT_FORMAT, 2, 4096 ) == -1 ) return 1;
  music[0] = NULL;
  music[0] = Mix_LoadMUS( "musica/fase1.mp3" );
  if(!music[0]){printf("0");return 1;}
  music[1] = NULL;
  music[1] = Mix_LoadMUS( "musica/fase2.mp3" );
  if(!music[1]){printf("1");return 1;}
  music[2] = NULL;
  music[2] = Mix_LoadMUS( "musica/fase3.mp3" );
  if(!music[2]){printf("2");return 1;}
  music[3] = NULL;
  music[3] = Mix_LoadMUS("musica/fase4.mp3");
  if(!music[3])return 1;
  music[4] = NULL;
  music[4] = Mix_LoadMUS("musica/enredo.mp3");
  if(!music[4])return 1;
  return 0;
}

/*! \brief Toca uma música
 * \param music Vetor de músicas
 * \param MusicNumber Índice do vetor no qual está armazenado a música desejada
 * \return 1 caso tenha ocorrido algum erro, 0 caso contrário */
int PlayMusic(Mix_Music **music, int MusicNumber){

  if( Mix_PlayMusic( music[MusicNumber], -1 ) == -1 ) 		return 1;
  else return 0;
}

/*! \brief Pausa a música em execução. Se a música já estiver pausada, ela volta a ser tocada */
void PauseMusic(){
  if( Mix_PausedMusic() == 1 ){
    Mix_ResumeMusic();
  }
  else{
    Mix_PauseMusic();
  }
}

/*! \brief Para a música em execução */
void StopMusic(){
  Mix_HaltMusic();
} 
