/*! \file barcoInimigo.c
 * \brief Arquivo que contém as funções referentes à movimentação do barco inimigo e ao carregamento de imagens */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "image.h"
#include "monstro.h"

Dot ataqueBarcoInimigo1 = NULL, ataqueBarcoInimigo2 = NULL;
int distanciaMaxima1, distanciaMaxima2;

/*! \brief Função responsável pelo carregamento da imagens do barco inimigo
 * \param vetorBarcoInimigo Vetor do tipo SDL_Surface onde serão armazenadas as figuras do barco inimigo */
void carregaVetorImagensBarcoInimigo(SDL_Surface **vetorBarcoInimigo)
{
  vetorBarcoInimigo[0] = load_image("imagens/monstros/barcoInimigo7.png");/*inclinacao de 135 graus*/
  vetorBarcoInimigo[1] = load_image("imagens/monstros/barcoInimigo15.png");/*inclinacao de 315 graus*/
  vetorBarcoInimigo[2] = load_image("imagens/monstros/barcoInimigo5.png");/*na vertical*/
  vetorBarcoInimigo[3] = load_image("imagens/monstros/barcoInimigo9.png");/*na horizontal*/
}

/*! \brief Função responsável por liberar os ataques do barco inimigo */
void liberaAtaquesBarcoInimigo()
{
  liberaDot(ataqueBarcoInimigo1);
  ataqueBarcoInimigo1 = NULL;
  liberaDot(ataqueBarcoInimigo2);
  ataqueBarcoInimigo2 = NULL;
}

/*! \brief Move o barco inimigo na diagonal
 * \param barcoInimigo Objeto representando o barco inimigo
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void moveBarcoInimigo(monstro barcoInimigo, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{
  int distancia = 5;
  barcoInimigo->objMonstro->x += distancia*cos(barcoInimigo->objMonstro->angulo);
  barcoInimigo->objMonstro->y -= distancia*sin(barcoInimigo->objMonstro->angulo);
  if(barcoInimigo->sentidoMov == SOBE){
    if(barcoInimigo->objMonstro->y + barcoInimigo->objMonstro->altura < 0){/*chegou na borda superior*/
      /*inverte o sentido e o angulo*/
      barcoInimigo->sentidoMov = DESCE;
      barcoInimigo->objMonstro->angulo += 3.141592654;
    }
  }
  else/*barcoInimigo->sentidoMov == DESCE*/{
    if(barcoInimigo->objMonstro->y + barcoInimigo->objMonstro->altura + 6 > SCREEN_HEIGHT){/*chegou na borda inferior*/
      barcoInimigo->sentidoMov = SOBE;
      barcoInimigo->objMonstro->angulo += 3.141592654;
    }
  }
  barcoInimigo->objMonstro->circulo->circuloX = barcoInimigo->objMonstro->x + (barcoInimigo->objMonstro->largura / 2);
  barcoInimigo->objMonstro->circulo->circuloY = barcoInimigo->objMonstro->y + (barcoInimigo->objMonstro->altura / 2);
}

/*! \brief Move o ataque lançado pelo barco inimigo
 * \param barcoInimigo Objeto representando o barco inimigo na fase
 * \param barco Barco do jogador
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void moveAtaqueBarcoInimigo(monstro barcoInimigo, Dot barco, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{
  int x, y, x1, y1, x2, y2;
  double angulo;
  x1 = barcoInimigo->objMonstro->circulo->circuloX;
  y1 = barcoInimigo->objMonstro->circulo->circuloY;
  x2 = barco->circulo->circuloX;
  y2 = barco->circulo->circuloY;
  angulo = atan(1.0 * (y2-y1) / (x2-x1)); 
  if(barcoInimigo->objMonstro->indiceVetor == 3 && x2 >= x1 - 100 && x2 <= x1 + 100
     && ataqueBarcoInimigo1 == NULL && ataqueBarcoInimigo2 == NULL){
    if(x2 >= x1 - 100 && x2 <= x1 + 25 && ataqueBarcoInimigo1 == NULL){
      x = barcoInimigo->objMonstro->x + (barcoInimigo->objMonstro->largura - 25) / 4; /*25 eh a largura da flecha*/
      y = barcoInimigo->objMonstro->y + (barcoInimigo->objMonstro->altura - 25) / 2; /*25 eh a altura da flecha*/
      ataqueBarcoInimigo1 = initDot(x, y, 25, 25, 0, FALSE, 0.0);
      ataqueBarcoInimigo1->distanciaPercorrida = 15;
      ataqueBarcoInimigo1->indiceVetor = 4;
      ataqueBarcoInimigo1->angulo = ataqueBarcoInimigo1->indiceVetor * 22.5 * 3.141592654 / 180;
      distanciaMaxima1 = 300;
    }
    if(x2 >= x1 - 25 && x2 <= x1 + 100 && ataqueBarcoInimigo2 == NULL){
      x = barcoInimigo->objMonstro->x + (3 * (barcoInimigo->objMonstro->largura - 25) / 4); /*25 eh a largura da flecha*/
      y = barcoInimigo->objMonstro->y + (barcoInimigo->objMonstro->altura - 25) / 2; /*25 eh a altura da flecha*/
      ataqueBarcoInimigo2 = initDot(x, y, 25, 25, 0, FALSE, 0.0);
      ataqueBarcoInimigo2->distanciaPercorrida = 15;
      ataqueBarcoInimigo2->indiceVetor = 4;
      ataqueBarcoInimigo2->angulo = ataqueBarcoInimigo2->indiceVetor * 22.5 * 3.141592654 / 180;
      distanciaMaxima2 = 300;
    }
  }
  else if(barcoInimigo->objMonstro->indiceVetor == 2  && y2 >= y1 - 100 && y2 <= y1 + 100 
	  && ataqueBarcoInimigo1 == NULL && ataqueBarcoInimigo2 == NULL){
    if(y2 >= y1 - 100 && y2 <= y1 + 25 && ataqueBarcoInimigo1 == NULL){
      x = barcoInimigo->objMonstro->x + (barcoInimigo->objMonstro->largura - 25) / 2; /*25 eh a largura da flecha*/
      y = barcoInimigo->objMonstro->y + (barcoInimigo->objMonstro->altura - 25) / 4; /*25 eh a altura da flecha*/
      ataqueBarcoInimigo1 = initDot(x, y, 25, 25, 0, FALSE, 0.0);
      ataqueBarcoInimigo1->distanciaPercorrida = 15;
      ataqueBarcoInimigo1->indiceVetor = 8;
      ataqueBarcoInimigo1->angulo = ataqueBarcoInimigo1->indiceVetor * 22.5 * 3.141592654 / 180;
      distanciaMaxima1 = 300;
    }
    if(y2 >= y1 - 25 && y2 <= y1 + 100 && ataqueBarcoInimigo2 == NULL){
      x = barcoInimigo->objMonstro->x + (barcoInimigo->objMonstro->largura - 25) / 2; /*25 eh a largura da flecha*/
      y = barcoInimigo->objMonstro->y + (3 * (barcoInimigo->objMonstro->altura - 25) / 4); /*25 eh a altura da flecha*/
      ataqueBarcoInimigo2 = initDot(x, y, 25, 25, 0, FALSE, 0.0);
      ataqueBarcoInimigo2->distanciaPercorrida = 15;
      ataqueBarcoInimigo2->indiceVetor = 8;
      ataqueBarcoInimigo2->angulo = ataqueBarcoInimigo2->indiceVetor * 22.5 * 3.141592654 / 180;
      distanciaMaxima2 = 300;
    }
  }
  else if((barcoInimigo->objMonstro->indiceVetor == 0 || barcoInimigo->objMonstro->indiceVetor == 1) && 
	  distancia(x1, y1, x2, y2) < 300 && (angulo >= 0 && angulo <= 3.141592654 / 2)  && ataqueBarcoInimigo1 == NULL){
    x = barcoInimigo->objMonstro->x + (barcoInimigo->objMonstro->largura - 25) / 2; /*25 eh a largura da flecha*/
    y = barcoInimigo->objMonstro->y + (barcoInimigo->objMonstro->altura - 25) / 2; /*25 eh a altura da flecha*/
    ataqueBarcoInimigo1 = initDot(x, y, 25, 25, 0, FALSE, 0.0);
    ataqueBarcoInimigo1->distanciaPercorrida = 15;
    if(x2 < x1)
      ataqueBarcoInimigo1->indiceVetor = 6;
    else
      ataqueBarcoInimigo1->indiceVetor = 14;
    ataqueBarcoInimigo1->angulo = ataqueBarcoInimigo1->indiceVetor * 22.5 * 3.141592654 / 180;
    distanciaMaxima1 = 250;
  }
  else{
    if(ataqueBarcoInimigo1 != NULL){
      x1 = ataqueBarcoInimigo1->x;
      y1 = ataqueBarcoInimigo1->y; 
      ataqueBarcoInimigo1->x += (int)(ataqueBarcoInimigo1->distanciaPercorrida * cos(ataqueBarcoInimigo1->angulo));
      ataqueBarcoInimigo1->circulo->circuloX += (int)ataqueBarcoInimigo1->distanciaPercorrida * cos(ataqueBarcoInimigo1->angulo);
      ataqueBarcoInimigo1->y += (int)ataqueBarcoInimigo1->distanciaPercorrida * sin(ataqueBarcoInimigo1->angulo) * -1;
      ataqueBarcoInimigo1->circulo->circuloY += (int)ataqueBarcoInimigo1->distanciaPercorrida * sin(ataqueBarcoInimigo1->angulo) * -1;
      x2 = ataqueBarcoInimigo1->x;
      y2 = ataqueBarcoInimigo1->y;
      distanciaMaxima1 -= distancia(x2, y2, x1, y1);
      if(checaColisao(barco->circulo, ataqueBarcoInimigo1->circulo)){
        barco->vida -= 10;
        liberaDot(ataqueBarcoInimigo1);
        ataqueBarcoInimigo1 = NULL;
        if(barco->vida <= 0)
	  barco->fase = GAME_OVER;
        
      }
      else if(distanciaMaxima1 <= 0 || x2 < 0 || x2 > SCREEN_WIDTH - 25 || y2 < 0 || y2 > SCREEN_HEIGHT - 25){
        liberaDot(ataqueBarcoInimigo1);
        ataqueBarcoInimigo1 = NULL;
      }
    }
    if(ataqueBarcoInimigo2 != NULL){
      x1 = ataqueBarcoInimigo2->x;
      y1 = ataqueBarcoInimigo2->y; 
      ataqueBarcoInimigo2->x += (int)ataqueBarcoInimigo2->distanciaPercorrida * cos(ataqueBarcoInimigo2->angulo);
      ataqueBarcoInimigo2->circulo->circuloX += (int)ataqueBarcoInimigo2->distanciaPercorrida * cos(ataqueBarcoInimigo2->angulo);
      ataqueBarcoInimigo2->y += (int)ataqueBarcoInimigo2->distanciaPercorrida * sin(ataqueBarcoInimigo2->angulo) * -1;
      ataqueBarcoInimigo2->circulo->circuloY += (int)ataqueBarcoInimigo2->distanciaPercorrida * sin(ataqueBarcoInimigo2->angulo) * -1;
      x2 = ataqueBarcoInimigo2->x;
      y2 = ataqueBarcoInimigo2->y;
      distanciaMaxima2 -= distancia(x2, y2, x1, y1);
      if(checaColisao(barco->circulo, ataqueBarcoInimigo2->circulo)){
        barco->vida -= 10;
        liberaDot(ataqueBarcoInimigo2);
        ataqueBarcoInimigo2 = NULL;
        if(barco->vida <= 0)
	  barco->fase = GAME_OVER;
      }
      else if(distanciaMaxima2 <= 0 || x2 < 0 || x2 > SCREEN_WIDTH - 25 || y2 < 0 || y2 > SCREEN_HEIGHT - 25){
        liberaDot(ataqueBarcoInimigo2);
        ataqueBarcoInimigo2 = NULL;
      }
    }
  }
}

/*! \brief Aplica o ataque do barco inimigo na tela
 * \param vetorAtaqueBarcoInimigo Vetor com as iamgens dos ataques do barco inimigo
 * \param screen Tela de jogo */
void imprimeAtaqueBarcoInimigo(SDL_Surface **vetorAtaqueBarcoInimigo, SDL_Surface *screen)
{
  if(ataqueBarcoInimigo1 != NULL)
    apply_surface(ataqueBarcoInimigo1->x, ataqueBarcoInimigo1->y, vetorAtaqueBarcoInimigo[(int)ataqueBarcoInimigo1->indiceVetor], screen, NULL);
  if(ataqueBarcoInimigo2 != NULL)
    apply_surface(ataqueBarcoInimigo2->x, ataqueBarcoInimigo2->y, vetorAtaqueBarcoInimigo[(int)ataqueBarcoInimigo2->indiceVetor], screen, NULL);
}
