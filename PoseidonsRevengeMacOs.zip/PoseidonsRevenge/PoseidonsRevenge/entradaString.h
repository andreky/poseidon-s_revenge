/*! \file entradaString.h
 * \brief Interface de entradaString.c com a definição do tipo nom */

/*!\brief Tipo usado para representar o nome passado pelo usuário, antes de começar a jogar */
typedef struct entradaNome *nom;
/*! \brief Estrutura para representar o nome */
struct entradaNome{
  /*! \brief String para armazenar o nome passado */
  char *nome;
  /*! \brief Indica a primeria posicao livre do vetor nome */
  int indiceVetor;
  /*! \brief Superficie com o nome do usuario */
  SDL_Surface *texto;
};

nom initStringInput();

void endStringInput(nom entrada);

void liberaNome(nom libera);

void handle_stringInput(nom entrada, SDL_Event event, TTF_Font *font, SDL_Color textColor);

void show_centered(nom entrada, int SCREEN_WIDTH, int SCREEN_HEIGHT, SDL_Surface *screen);
