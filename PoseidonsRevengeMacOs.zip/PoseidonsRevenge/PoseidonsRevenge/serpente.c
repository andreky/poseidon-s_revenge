/*! \file serpente.c
 * \brief Arquivo com o carregamento de imagens da serpente e sua movimentação */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "image.h"
#include "monstro.h"

/*! \brief Distância máxima que a serpente pode percorrer */
#define DISTANCIA_MAX 100

/*! \brief Função responsável pelo carregamento das imagens da serpente
 * \param vetorSerpente Vetor do tipo SDL_Surface onde serão armazenadas as figuras das serpentes */
void carregaVetorImagensSerpente(SDL_Surface **vetorSerpente)
{
  vetorSerpente[0] = load_image("imagens/monstros/serpente1.png");
  vetorSerpente[1] = load_image("imagens/monstros/serpente2.png");
}

/*! \brief Move a serpente
 * \param serpente Objeto que representa uma serpente
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void moveSerpente(monstro serpente, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{
  int distanciaX = 5;
  int mudaSentido = rand()%20;
  serpente->objMonstro->x += distanciaX * serpente->sentidoMov;
  if(serpente->objMonstro->x < serpente->initX){
    if(mudaSentido == 0)
      serpente->sentidoMov *= -1;
    serpente->objMonstro->x = serpente->initX;	
  }
  if(serpente->objMonstro->x > DISTANCIA_MAX + serpente->initX){
    if(mudaSentido == 0)
      serpente->sentidoMov *= -1;
    serpente->objMonstro->x = DISTANCIA_MAX + serpente->initX;
  }
  serpente->objMonstro->circulo->circuloX = serpente->objMonstro->x + (serpente->objMonstro->largura / 2);
}
