/*! \file timer.c
 * \brief Arquivo com as funções do timer. Todas as funções foram retiradas do tutorial de SDL do lazyfoo */
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "timer.h"

/*! \brief Inicializa um novo timer
 * \return Um novo timer */
Timer initTimer()
{
  Timer timer;
  timer = malloc(sizeof *timer);
  timer->startTicks = 0;
  timer->pausedTicks = 0;
  timer->paused = FALSE;
  timer->started = FALSE;
  return timer;
}

/*! \brief Inicia um timer
 * \param timer Timer a ser iniciado */
void start(Timer timer)
{
  /*Start the timer*/
  timer->started = TRUE;
  /*Unpause the timer*/
  timer->paused = FALSE;
  /*Get the current clock time*/
  timer->startTicks = SDL_GetTicks();
}

/*! \brief Para um timer
 * \param timer Timer a ser parado */
void stop(Timer timer)
{
  /*Stop the timer*/
  timer->started = FALSE;
  /*Unpause the timer*/
  timer->paused = FALSE;
}

/*! \brief Pausa um timer
 * \param timer Timer a ser pausado */
void pause(Timer timer)
{
  /*If the timer is running and isn't already paused*/
  if((timer->started == TRUE) && (timer->paused == FALSE)){
    /*Pause the timer*/
    timer->paused = TRUE;
    /*Calculate the paused ticks*/
    timer->pausedTicks = SDL_GetTicks() - timer->startTicks;
  }
}

/*! \brief Despausa um timer
 * \param timer Timer a ser despausado */
void unpause(Timer timer)
{
  /*If the timer is paused*/
  if(timer->paused == TRUE){
    /*Unpause the timer*/
    timer->paused = FALSE;
    /*Reset the starting ticks*/
    timer->startTicks = SDL_GetTicks() - timer->pausedTicks;
    /*Reset the paused ticks*/
    timer->pausedTicks = 0;
  }
}

int get_ticks(Timer timer)
{
  /*If the timer is running*/
  if(timer->started == TRUE){
    /*If the timer is paused*/
    if(timer->paused == TRUE){
      /*Return the number of ticks when the timer was paused*/
      return timer->pausedTicks;
    }
    else{
      /*Return the current time minus the start time*/
      return SDL_GetTicks() - timer->startTicks;
    }
  }
  /*If the timer isn't running*/
  return 0;
}

int is_started(Timer timer)
{
  return timer->started;
}

int is_paused(Timer timer)
{
  return timer->paused;
}
