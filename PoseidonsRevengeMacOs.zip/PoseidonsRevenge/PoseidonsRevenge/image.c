/*! \file image.c
 * \brief Arquivo que contem as funções de carregamento e aplicação de imagens. Essa funções foram retiradas do tutorial de SDL do lazyfoo.*/
#include <string.h>
#include "SDL/SDL.h"
#include "SDL_image.h"

/*! \brief Carrega uma imagem a partir do nome da imagem
 * \param filename Nome ou caminho para a imgem
 * \return A imagem carregada no tipo *SDL_Surface */
SDL_Surface *load_image(char *filename)
{
  SDL_Surface* loadedImage = NULL;
  SDL_Surface* optimizedImage = NULL;
  loadedImage = IMG_Load(filename);
  if(loadedImage != NULL){
    optimizedImage = SDL_DisplayFormat(loadedImage);
    SDL_FreeSurface(loadedImage);
    if( optimizedImage != NULL ){
      SDL_SetColorKey(optimizedImage, SDL_SRCCOLORKEY, SDL_MapRGB(optimizedImage->format, 0, 0xA2, 0xC7));
    }
  }
  return optimizedImage;
}

/*! \brief Aplica uma imagem (tipo SDL_Surface)
 * \param x Coordenada x onde a imagem será aplicada
 * \param y Coordenada y onde a imagem será aplicada
 * \param source A imagem a ser aplicada
 * \param destination Onde a imagem será aplicada, geralmente é a tela de jogo 
 * \param clip Argumento que neste projeto é sempre NULL */
void apply_surface(int x, int y, SDL_Surface* source, SDL_Surface* destination, SDL_Rect* clip)
{
  SDL_Rect offset;
  offset.x = x;
  offset.y = y;
  SDL_BlitSurface(source, clip, destination, &offset);
}
