/*! \file monstro.h
 * \brief Interface de monstro.c e dos outros arquivos de monstros/inimigos com a definição do tipo monstro */

#include "bolas.h"

#define SOBE 0
#define DESCE 1

#define TRUE 1
#define FALSE 0

#define KRAKEN 1
#define SERPENTE 2
#define HARPIA 3
#define BARCOINIMIGO 4
#define SEREIA 5
#define TORNADO 6
#define CATAPULTA 7

#define MENU 0
#define INSTRUCOES1 1
#define INSTRUCOES2 2
#define CREDITOS 3
#define ENREDO1 4
#define ENREDO2 5
#define ENREDO3 6
#define FASE_1 7
#define FASE_2 8
#define FASE_3 9 
#define FASE_4 10
#define YOU_WIN 11
#define GAME_OVER 12
#define UPGRADE 13
#define RANKING 14

/*! \brief Tipo usado para representar os monstros das fases. Cada fase tem uma lista ligada de monstros */
typedef struct celMonstro *monstro;
/*! \brief Estrutura usada para representar o tipo monstro. Também usada para fazer a lista liagada de monstros de cada fase */
struct celMonstro
{
  /*! \brief Objeto do tipo Dot usado para a movimentacao do monstro, colisoes e marcacao das vidas dos monstros */
  Dot objMonstro;
  /*! \brief Numero que indica qual monstro a celula representa. Ver defines acima */
  int indicaMonstro;
  /*! \brief X inicial do monstro */
  int initX;
  /*! \brief Y inicial do monstro */
  int initY;
  /*! \brief Sentido de movimento do monstro. Ver defines do arquivo .c de cada monstro para maiores informacoes */
  int sentidoMov;
  /*! \brief Ponteiro para o proximo monstro da lista */
  monstro next;
};

/*Usado por todos os monstros para a inicialização e liberação */
monstro initMonstro(int indicaMonstro, int Xini, int Yini, int largura, int altura, int vida, float angulo, int sentidoMovimento);

void liberaMonstro(monstro libera);

/*Usado por todos os monstros para detectar colisões */
int aumentouDistanciaMonstro(circ barco, monstro cabeca, int deltaX, int deltaY);

int colisaoBarco(Dot barco, monstro cabeca);

int colisaoAtaqueUnico(Dot ataque, monstro cabeca, int dano, Dot barco);

void colisaoAtaqueArea(Dot ataque, monstro cabeca, int dano, Dot barco);

/*Funções das catapultas e das pedras */
void initCatapulta(SDL_Surface **vetorCatapulta, SDL_Surface **vetorPedra, SDL_Surface **vetorIlhaCatapulta);

Dot initIlhaCatapulta(int x, int y, int largura, int altura, int centroX, int centroY, int raio);

void liberaPedra();

void lancaPedra(monstro catapulta, Dot barco, int SCREEN_HEIGHT);

void imprimePedra(SDL_Surface **vetorPedra, SDL_Surface *screen);

/*Funções das sereias */
void initSereia(SDL_Surface **vetorSereia);

Dot initIlhaSereia(int x, int y, int largura, int altura, int raio);

void moveBarcoSereia(Dot sereia, Dot barco, double raioAtracao, double distanciaAtracao, monstro cabecaMonstro);

/*Funções do barco inimigo */
void carregaVetorImagensBarcoInimigo(SDL_Surface **vetorBarcoInimigo);

void liberaAtaquesBarcoInimigo();

void moveBarcoInimigo(monstro barcoInimigo, int SCREEN_WIDTH, int SCREEN_HEIGHT);

void moveAtaqueBarcoInimigo(monstro barcoInimigo, Dot barco, int SCREEN_WIDTH, int SCREEN_HEIGHT);

void imprimeAtaqueBarcoInimigo(SDL_Surface **vetorAtaqueBarcoInimigo, SDL_Surface *screen);

/*Funções das harpias */
void carregaVetorImagensHarpia(SDL_Surface **vetorHarpia);

void moveHarpia(monstro harpia, int SCREEN_WIDTH, int SCREEN_HEIGHT);

/*Funções das serpentes */
void carregaVetorImagensSerpente(SDL_Surface **vetorSerpente);

void moveSerpente(monstro sepente, int SCREEN_WIDTH, int SCREEN_HEIGHT);

/*Funções do kraken */
void carregaVetorImagensKraken(SDL_Surface **vetorKraken, SDL_Surface **vetorAtaqueKraken);

void liberaAtaqueKraken();

void moveAtaque(Dot barco, monstro kraken);

void moveKraken(monstro kraken, int SCREEN_WIDTH, int SCREEN_HEIGHT);

void imprimeAtaqueKraken(SDL_Surface **vetorAtaqueKraken, SDL_Surface *screen);

/*Funções dos tornados */
void carregaVetorImagensTornado(SDL_Surface **vetorTornado);

void moveBarcoTornado(Dot atracao, Dot barco, double raio, monstro cabecaMonstro);
