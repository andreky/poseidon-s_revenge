typedef struct ranking *rank;
struct ranking{
  char *nome;
  int pontuacao;
  int posicao;
  rank next;
};

void carregaBotaoRanking(SDL_Surface **vetorBotaoRanking);

char *converteInteiroString(int pontuacao);

void abreRanking();

void imagensRanking(SDL_Surface **posicao, SDL_Surface **nomes, SDL_Surface **pontuacao, TTF_Font *font, SDL_Color textColor);

int checaPontuacao(char *jogadorNome, int jogadorPontuacao);

void liberaRanking();
