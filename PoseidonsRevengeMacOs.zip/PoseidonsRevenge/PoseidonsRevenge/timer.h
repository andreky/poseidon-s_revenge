/*! \file timer.h
 * \brief Interface de timer.c com a definição do tipo Timer */

#define TRUE 1
#define FALSE 0

/*! \brief Tipo usado para representar o relógio do jogo, chamamos esse tipo de Timer */
typedef struct timer *Timer;
/*! \brief Estrutura do tipo Timer, ou seja, do relógio */
struct timer{
  /*! \brief O tempo desde que o timer foi iniciado */
  int startTicks;
  /*! \brief O tempo do timer pausado */
  int pausedTicks;
  /*! \brief Vale 1 se o timer está pausado, 0 caso contrário */
  int paused;
  /*! \brief Vale 1 se o timer foi iniciado, 0 caso contrário */
  int started;
};

Timer initTimer();

void start(Timer timer);

void stop(Timer timer);

void pause(Timer timer);

void unpause(Timer timer);

int get_ticks(Timer timer);

int is_started(Timer timer);

int is_paused(Timer timer);
