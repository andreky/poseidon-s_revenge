Grupo:
André Kenji Yai NUSp: 7156379
Lucas Takeshi Rodrigues Palma NUsp: 7577480
Rafael Mota Gregorut NUsp: 7577431

Os desenhos da tela de enredo foram feitos por Tuanny Harumi
Os desenhos do barco e dos monstros foram feitos por Gabriela Akemi Shima

O manual do desenvolver foi gerado com o Doxygen e está em documentacao/latex/ref.tex (também estou mandando a documentação em html: documentacao/html/index.html e em pdf: documentacao/latex/refman.pdf 
