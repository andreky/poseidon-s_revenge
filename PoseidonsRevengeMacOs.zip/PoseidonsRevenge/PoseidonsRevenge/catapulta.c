/*! \file catapulta.c 
 * \brief Arquivo que contem as funções à inicialização das catapultas e à movimentação das pedras */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "image.h"
#include "monstro.h"

/*! \brief Uma pedra a ser lançada */
Dot pedra = NULL;
/*! \brief A distância máxima que uma pedra pode percorrer */
int distanciaMaxima;

/*! \brief Inicializa a catapulta, sua ilha e a pedra, carregando todas as imagens desses elementos
 * \param vetorCatapulta Vetor onde será aramazenada a imagem da catapulta
 * \param vetorPedra Vetor onde será armazenada a imagem da pedra
 * \param vetorIlhaCatapulta Vetor onde será armazenada a imagem da ilha */
void initCatapulta(SDL_Surface **vetorCatapulta, SDL_Surface **vetorPedra, SDL_Surface **vetorIlhaCatapulta)
{
  vetorCatapulta[0] = load_image("imagens/monstros/catapulta.png");
  vetorPedra[0] = load_image("imagens/ataques/pedra.png");
  vetorIlhaCatapulta[0] = load_image("imagens/cenario/ilhaCatapulta.png");
}

/*! \brief Inicializa uma ilha de catapultas
 * \param x Coordenada x da ilha
 * \param y Coordenada y da ilha
 * \param largura Largura da imagem da ilha
 * \param altura Altura da imagem da ilha 
 * \param centroX Coordenada x do centro da ilha
 * \param centroY coordenada y do centro da ilha
 * \param raio Raio da ilha para colisões
 * \return A nova ilha */
Dot initIlhaCatapulta(int x, int y, int largura, int altura, int centroX, int centroY, int raio)
{
  Dot ilhaCatapulta;
  ilhaCatapulta = initDot(x, y, largura, altura, 0, TRUE, 0.0);
  ilhaCatapulta->circulo->circuloX = centroX;
  ilhaCatapulta->circulo->circuloY = centroY;
  ilhaCatapulta->circulo->raio = raio;
  return ilhaCatapulta;
}

/*! \brief Libera a pedra */
void liberaPedra()
{
  liberaDot(pedra); 
  pedra = NULL;
}

/*! \brief Move uma pedra lançada pela catapulta
 * \param catapulta Catapulta que lança a pedra
 * \param barco Barco do jogador 
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void movePedra(monstro catapulta, Dot barco, int SCREEN_HEIGHT)
{
  int novoY;
  novoY = pedra->y + pedra->distanciaPercorrida;
  if(novoY <= SCREEN_HEIGHT - pedra->altura){
    pedra->y += pedra->distanciaPercorrida;
    pedra->circulo->circuloY += pedra->distanciaPercorrida;
    if(checaColisao(barco->circulo, pedra->circulo)){
      barco->vida -= 20;
      liberaPedra(pedra);
      if(barco->vida <= 0)
      	barco->fase = GAME_OVER;
    }
    else if(pedra->y - catapulta->objMonstro->y > distanciaMaxima)
      liberaPedra(pedra);
  }
  else
    liberaPedra(pedra);
}


/*! \brief Lança uma pedra. A distância máxima que essa pedra vai percorrer é aleatória, mas não passa da barra inferior. 
 * \param catapulta Catapulta de onde será lançada a pedra
 * \param barco Barco do jogador 
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void lancaPedra(monstro catapulta, Dot barco, int SCREEN_HEIGHT)
{
  int distanciaAleatoria;
  if(barco->x >= catapulta->objMonstro->x - 50 && barco->x <= catapulta->objMonstro->x + catapulta->objMonstro->largura + 50){
    if(pedra == NULL){
      pedra = initDot(catapulta->objMonstro->x+(catapulta->objMonstro->largura-25)/2, catapulta->objMonstro->y, 25, 25, 0, FALSE, 0.0);
      pedra->distanciaPercorrida = 5;
      distanciaAleatoria = (rand() % 200) - 100;
      distanciaMaxima = barco->y + distanciaAleatoria;
    }
  }
  if(pedra != NULL)
    movePedra(catapulta, barco, SCREEN_HEIGHT);
}

/*! \brief Aplica a imagem de uma pedra na tela
 * \param vetorPedra Vetor com a iamgem da pedra
 * \param screen A tela de jogo */
void imprimePedra(SDL_Surface **vetorPedra, SDL_Surface *screen)
{
  if(pedra != NULL)
    apply_surface(pedra->x, pedra->y, vetorPedra[0], screen, NULL);
}
