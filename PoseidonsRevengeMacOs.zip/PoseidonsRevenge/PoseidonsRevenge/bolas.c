/*! \file bolas.c
 * \brief Arquivo com as funções pertinentes aos itens a serem coletados durante as fase */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "SDL/SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include "SDL_mixer.h"
#include "timer.h"
#include "bolas.h"

/*! \brief Vetor onde são armazenadas as bolinhas a serem coletadas */
Dot bolas[8];
/*! \brief Imagem dos itens de magia */
SDL_Surface *magia = NULL;
/*! \brief Imagem dos itens de energia*/
SDL_Surface *energia = NULL;
/*! \brief Imagem dos itens de vida*/
SDL_Surface *vida = NULL;
/*! \brief Imagem dos itens de dinheiro/pontuação */
SDL_Surface *dinheiro = NULL;

/*! \brief Função de inicilização dos itens. Cada bolinha recebe uma posição as imagens correspondentes são carregadas */
void initBolas()
{
  bolas[0] = initDot(0,0,19,18,0,0,0);
  bolas[1] = initDot(0,0,19,18,0,0,0);
  bolas[2] = initDot(0,0,18,16,0,0,0);
  bolas[3] = initDot(0,0,18,16,0,0,0);
  bolas[4] = initDot(0,0,17,16,0,0,0);
  bolas[5] = initDot(0,0,17,16,0,0,0);
  bolas[6] = initDot(0,0,15,25,0,0,0);
  bolas[7] = initDot(0,0,15,25,0,0,0);
  vida = load_image("imagens/coletaveis/bolaVida.png");
  magia = load_image("imagens/coletaveis/bolaMagia.png");
  energia = load_image("imagens/coletaveis/bolaEnergia.png");
  dinheiro = load_image("imagens/coletaveis/dinheiro.png");
}

/*! \brief Função de liberação dos itens */
void liberaBolas()
{
  int i;
  for(i = 0; i < 8; i++)
    liberaDot(bolas[i]);
  SDL_FreeSurface(magia);
  SDL_FreeSurface(energia);
  SDL_FreeSurface(vida);
  SDL_FreeSurface(dinheiro);
  
}

/*! \brief Determina uma posição aleatória para cada item (bolinha/dinheiro) de maneira que nenhum deles caia em uma área de acesso impossível ao jogador 
 * \param x Coordenada x do canto superior esquerdo da área de aplicação dos itens
 * \param y Coordenada y do canto superiro esquerdo da área de aplicação dos itens 
 * \param obstaculo1 Objeto da fase que impede a aplicação dos itens em determinada área
 * \param obstaculo2 Objeto da fase que impede a aplicação dos itens em determinada área 
 * \param obstaculo3 Objeto da fase que impede a aplicação dos itens em determinada área
 * \param porto Porto presente em cada fase */
void bolasPosicao(int x,int y,int fase,Dot obstaculo1,Dot obstaculo2,Dot obstaculo3, Dot porto)
{ 
  int i,j;
  for(i = 0;i < 8;i++){
    bolas[i]->energia = 0;
    bolas[i]->magia = 0;
    bolas[i]->vida = 0;
    bolas[i]->pontos = 0;
  }
  for(i = 0;i < 8;i++){
    while(1){
      bolas[i]->x = x+(rand()%800);
      bolas[i]->y = y+(rand()%350);
      for(j = 0;j < i;j++){
	if(bolas[i]->x == bolas[j]->x)
	  if(bolas[i]->y == bolas[j]->y)
	    break;
      }
      if(j == i &&(bolas[i]->x > 0 && bolas[i]->x < 850) &&(bolas[i]->y > 0 && bolas[i]->y < 400)) break;
		
    }
    if(i < 2){
      bolas[i]->magia = 1;
      bolas[i]->circulo->circuloX = bolas[i]->x + (19/2);
      bolas[i]->circulo->circuloY = bolas[i]->y + (18/2);
      if(fase == 1 ||fase == 3)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;
      if(fase == 2)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo3->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;
    }
    if(i == 2 || i == 3 ){
      bolas[i]->energia = 1;
      bolas[i]->circulo->circuloX = bolas[i]->x + (18/2);
      bolas[i]->circulo->circuloY = bolas[i]->y + (16/2);
      if(fase == 1 ||fase == 3)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;
      if(fase == 2)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo3->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;
    }
    if(i == 4 || i == 5){
      bolas[i]->vida = 1;
      bolas[i]->circulo->circuloX = bolas[i]->x + (17/2);
      bolas[i]->circulo->circuloY = bolas[i]->y + (16/2);
      if(fase == 1 ||fase == 3)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;
      if(fase == 2)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo3->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;
    }
    if(i == 6 || i == 7){
      bolas[i]->pontos = 1;
      bolas[i]->circulo->circuloX = bolas[i]->x + (15/2);
      bolas[i]->circulo->circuloY = bolas[i]->y + (25/2);
      if(fase == 1 ||fase == 3)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;
      if(fase == 2)
	if(checaColisao(obstaculo1->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo2->circulo,bolas[i]->circulo) == TRUE || checaColisao(obstaculo3->circulo,bolas[i]->circulo) == TRUE || checaColisao(porto->circulo,bolas[i]->circulo) == TRUE) 
	  i--;

    }
  }
}

/*! \brief Aplica os itens na tela de jogo
 * \param screen Tela de jogo
 * \param barco Barco do jogador */
void imprimeBolas(SDL_Surface *screen,Dot barco)
{
  if(bolas[0]->magia == 1){
    if(checaColisao(barco->circulo,bolas[0]->circulo) == FALSE) 
      apply_surface(bolas[0]->x,bolas[0]->y,magia, screen,NULL);
    else{
      bolas[0]->magia = 0;
      if(barco->magia < 200){
	if(barco->magia > 175)
	  barco->magia = 200;
	else barco->magia += 25;
      }
    }
  }
  if(bolas[1]->magia == 1){
    if(checaColisao(barco->circulo,bolas[1]->circulo) == FALSE) 
      apply_surface(bolas[1]->x,bolas[1]->y,magia, screen,NULL);
    else{
      bolas[1]->magia = 0;
      if(barco->magia < 200){
	if(barco->magia > 175)
	  barco->magia = 200;
	else barco->magia += 25;		
      }
    }	
  }
  if(bolas[2]->energia == 1){
    if(checaColisao(barco->circulo,bolas[2]->circulo) == FALSE) 
      apply_surface(bolas[2]->x,bolas[2]->y,energia, screen,NULL);
    else{
      bolas[2]->energia = 0;
      if(barco->energia < 200){
	if(barco->energia > 175) 
	  barco->energia = 200;
	else barco->energia += 25;
      }
    }
  }	
  if(bolas[3]->energia == 1){
    if(checaColisao(barco->circulo,bolas[3]->circulo) == FALSE) 
      apply_surface(bolas[3]->x,bolas[3]->y,energia, screen,NULL);
    else{
      bolas[3]->energia = 0;
      if(barco->energia != 200){
	if(barco->energia > 175)
	  barco->energia = 200;
				
	else barco->energia += 25;		
      }
    }
  }
  if(bolas[4]->vida == 1){
    if(checaColisao(barco->circulo,bolas[4]->circulo) == FALSE) 
      apply_surface(bolas[4]->x,bolas[4]->y,vida, screen,NULL);
    else{
      bolas[4]->vida = 0;
      if(barco->vida != 200){
	if(barco->vida > 175)
	  barco->vida = 200;
	else barco->vida += 25;
      }
    }
  }
  if(bolas[5]->vida == 1){
    if(checaColisao(barco->circulo,bolas[5]->circulo) == FALSE) 
      apply_surface(bolas[5]->x,bolas[5]->y,vida, screen,NULL);
    else{
      bolas[5]->vida = 0;
      if(barco->vida != 200){
	if(barco->vida > 175) 
	  barco->vida = 200;
	else barco->vida += 25;
      }	
    }
  }
  if(bolas[6]->pontos == 1){
    if(checaColisao(barco->circulo,bolas[6]->circulo) == FALSE) 
      apply_surface(bolas[6]->x,bolas[6]->y,dinheiro, screen,NULL);
    else{
      bolas[6]->pontos = 0;
      barco->pontos += 25;
    }
  }
  if(bolas[7]->pontos == 1){
    if(checaColisao(barco->circulo,bolas[7]->circulo) == FALSE) 
      apply_surface(bolas[7]->x,bolas[7]->y,dinheiro, screen,NULL);
    else{
      bolas[7]->pontos = 0;
      barco->pontos += 25;
    }
  }
}
